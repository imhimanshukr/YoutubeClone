<template>
    <div>
      <v-app-bar
        color="mainBg"
        elevation="0"
      >
        <v-icon class="fs-26 pointer ml-0 ml-sm-0 mr-5" color="primaryText" @click.stop="$store.state.drawer = !$store.state.drawer">mdi-menu</v-icon>
  
        <img width="90px" class="pointer" src="../assets/dark-logo.png" alt="logo" v-if="$vuetify.theme.dark">
        <img width="90px" class="pointer" src="../assets/light-logo.png" alt="logo" v-if="!$vuetify.theme.dark">
  
        <v-spacer></v-spacer>
        
        <v-autocomplete
  clearable
  dense
  outlined
  rounded
  hide-details
  hide-no-data
>
  <template #append>
    <v-icon class="no-rotate">
      mdi-magnify
    </v-icon>
  </template>
</v-autocomplete>

        
        <v-spacer></v-spacer>
        <v-btn icon>
          <v-icon>{{$vuetify.theme.dark ? 'mdi-video-plus' : 'mdi-video-plus-outline'}}</v-icon>
        </v-btn>
        <v-btn icon @click="$vuetify.theme.dark = !$vuetify.theme.dark">
          <v-icon>mdi-bell-outline</v-icon>
        </v-btn>
  
        <v-menu
          left
          bottom
        >
          <template v-slot:activator="{ on, attrs }">
            <v-btn
              icon
              v-bind="attrs"
              v-on="on"
            >
              <v-avatar size="35"><img src="https://lh3.googleusercontent.com/a/AGNmyxZ7qhL59QyDyrMQnr4OloKhOWgpWNeNXk3p1Y3Z" alt=""></v-avatar>
            </v-btn>
          </template>
  
          <v-list>
            <v-list-item
              v-for="n in 5"
              :key="n"
              @click="() => {}"
            >
              <v-list-item-title>Option {{ n }}</v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </v-app-bar>
    </div>
  </template>

<script>
    export default {
        data(){
            return{

            }
        }
    }
</script>

<style scoped>
.no-rotate {
  transform: none !important;
}

</style>