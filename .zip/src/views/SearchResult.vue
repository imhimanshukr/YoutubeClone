<template>
    <div>
        <RelatedVideo/>
    </div>
</template>

<script>
import { mapActions } from "vuex";
import RelatedVideo from '@/components/RelatedVideo.vue';
    export default {
        mounted(){
            this.fetchRelatedVideos(this.videoId);
        },
        methods: {
            ...mapActions(["fetchRelatedVideos"]),
        },
        components:{
            RelatedVideo,
        }
    }
</script>

<style lang="scss" scoped>

</style>