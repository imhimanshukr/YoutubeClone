import Vue from 'vue'
import Vuex from 'vuex'
// import { fetchDataFromApi } from '@/api';
import data from "./dummy.JSON";

Vue.use(Vuex)
export default new Vuex.Store({
  state: {
    drawer: false,
    videos: [],
    feedTitle:[],
    videoDetail: null,
    relatedContent: [],
    hideSidebar: false,
    videoComments: [],
  },
  getters: {
  },
  mutations: {
    setVideos(state, videos) {
      state.videos = videos;
    },
    setFeedTitle(state, feedTitle) {
      state.feedTitle = feedTitle;
    },
    setVideoDetail(state, videoDetail) {
      state.videoDetail = videoDetail;
    },
    setRelatedContent(state, relatedContent) {
      state.relatedContent = relatedContent;
    },
    setVideoComment(state, videoComments) {
      state.videoComments = videoComments;
    },
  },
  actions: {
    async fetchVideoDetail({commit}, videoId) {
      console.log("VI: ", videoId);
      console.log("VI Detail: ", data.desc);
      // const response = await fetchDataFromApi(`video/details/?id=${videoId}`);
      // console.log("recommendationFeedTitle: ", response);
      commit("setVideoDetail", data.desc);
    },
    async fetchVideos({ commit }, query) {
    //   const response = await fetchDataFromApi(`search/?q=${query}`);
      // console.log("videos: ", response.contents);
    console.log("videos list: ", data.videos);
      commit("setFeedTitle", query);
      commit("setVideos", data.videos);
    },
    async fetchRelatedVideos({commit}, videoId){
        // const response = await fetchDataFromApi(`video/related-contents/?id=${videoId}`);
        // commit("setRelatedContent", response.contents);
        console.log("related: ", data.related, videoId);
      commit("setRelatedContent", data.related);

    },
    async fetchVideoComment({commit}, videoId){
        // const response = await fetchDataFromApi(`video/comments/?id=${videoId}`);
        // commit("setVideoComment", response);
        console.log("data.commentData:", videoId, data.commentData);
        commit("setVideoComment", data.commentData);
    }
  },
  modules: {
  }
})

/*
import axios from 'axios';

const options = {
  method: 'GET',
  url: 'https://youtube138.p.rapidapi.com/auto-complete/',
  params: {
    q: 'desp',
    hl: 'en',
    gl: 'US'
  },
  headers: {
    'X-RapidAPI-Key': 'ab806c9d26mshfdbb2785037ac9bp16b07fjsn0e4d82ad3407',
    'X-RapidAPI-Host': 'youtube138.p.rapidapi.com'
  }
};

try {
	const response = await axios.request(options);
	console.log(response.data);
} catch (error) {
	console.error(error);
}
*/